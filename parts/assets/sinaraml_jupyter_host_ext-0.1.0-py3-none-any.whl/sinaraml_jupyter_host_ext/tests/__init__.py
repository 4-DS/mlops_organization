"""Python unit tests for sinaraml_jupyter_host_ext."""
